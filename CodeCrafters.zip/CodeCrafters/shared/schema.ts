import { pgTable, text, serial, integer, real, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const brewingParameters = pgTable("brewing_parameters", {
  id: serial("id").primaryKey(),
  // Bean Properties
  moisture_content: real("moisture_content").notNull(),
  oil_level: text("oil_level").notNull(),
  roast_profile: text("roast_profile").notNull(),
  bean_density: real("bean_density").notNull(),
  bean_species: text("bean_species").notNull(),
  bean_age_days: integer("bean_age_days").notNull(),
  storage_condition: text("storage_condition").notNull(),
  
  // Grinder Settings
  grind_size_microns: integer("grind_size_microns").notNull(),
  burr_type: text("burr_type").notNull(),
  burr_alignment: text("burr_alignment").notNull(),
  burr_material: text("burr_material").notNull(),
  grinder_rpm: integer("grinder_rpm").notNull(),
  static_effect: text("static_effect").notNull(),
  retention_g: real("retention_g").notNull(),
  grind_heat_celsius: real("grind_heat_celsius").notNull(),
  
  // Machine Parameters
  brew_pressure_bar: real("brew_pressure_bar").notNull(),
  brew_temp_celsius: real("brew_temp_celsius").notNull(),
  temp_stability_score: text("temp_stability_score").notNull(),
  flow_rate_g_per_sec: real("flow_rate_g_per_sec").notNull(),
  preinfusion_sec: real("preinfusion_sec").notNull(),
  boiler_type: text("boiler_type").notNull(),
  pump_type: text("pump_type").notNull(),
  basket_type: text("basket_type").notNull(),
  water_quality_tds_ppm: integer("water_quality_tds_ppm").notNull(),
  water_pH: real("water_pH").notNull(),
  
  // Environment
  ambient_temp_celsius: real("ambient_temp_celsius").notNull(),
  humidity_percent: real("humidity_percent").notNull(),
  altitude_meters: real("altitude_meters").notNull(),
  barometric_pressure_kpa: real("barometric_pressure_kpa").notNull(),
  
  // Barista Technique
  tamping_force_lbs: real("tamping_force_lbs").notNull(),
  tamping_consistency: text("tamping_consistency").notNull(),
  distribution_method: text("distribution_method").notNull(),
  dose_grams: real("dose_grams").notNull(),
  shot_time_sec: real("shot_time_sec").notNull(),
  yield_grams: real("yield_grams").notNull(),
  brew_ratio: real("brew_ratio").notNull(),
});

export const shotSessions = pgTable("shot_sessions", {
  id: serial("id").primaryKey(),
  session_id: text("session_id").notNull(),
  parameter_id: integer("parameter_id").references(() => brewingParameters.id),
  estimated_score: integer("estimated_score").notNull(),
  actual_score: integer("actual_score"),
  tasting_notes: text("tasting_notes"),
  crema_quality: text("crema_quality"),
  shot_rating: text("shot_rating"),
  created_at: timestamp("created_at").defaultNow().notNull(),
});

export const insertBrewingParametersSchema = createInsertSchema(brewingParameters).omit({
  id: true,
});

export const insertShotSessionSchema = createInsertSchema(shotSessions).omit({
  id: true,
  created_at: true,
});

export type InsertBrewingParameters = z.infer<typeof insertBrewingParametersSchema>;
export type BrewingParameters = typeof brewingParameters.$inferSelect;
export type InsertShotSession = z.infer<typeof insertShotSessionSchema>;
export type ShotSession = typeof shotSessions.$inferSelect;
