import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Coffee, Download, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { ParameterInputForm } from "@/components/parameter-input-form";
import { QualityAnalysisComponent } from "@/components/quality-analysis";
import { ShotHistory } from "@/components/shot-history";
import { ImportExport } from "@/components/import-export";
import { BrewingParameters, getDefaultParameters, calculateQualityScore, QualityAnalysis } from "@/lib/espresso-scoring";
import { apiRequest } from "@/lib/queryClient";
import { ShotSession, BrewingParameters as DBBrewingParameters, InsertBrewingParameters, InsertShotSession } from "@shared/schema";
import { ExportData } from "@/lib/data-export";

export default function Home() {
  const [parameters, setParameters] = useState<BrewingParameters>(getDefaultParameters());
  const [currentAnalysis, setCurrentAnalysis] = useState<QualityAnalysis | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Load shot sessions
  const { data: shotSessions = [], isLoading: sessionsLoading } = useQuery({
    queryKey: ['/api/shot-sessions'],
  });

  // Load brewing parameters (for shot history)
  const { data: brewingParamsList = [], isLoading: paramsLoading } = useQuery({
    queryKey: ['/api/brewing-parameters'],
  });

  // Save brewing parameters mutation
  const saveParametersMutation = useMutation({
    mutationFn: async (params: InsertBrewingParameters) => {
      const response = await apiRequest('POST', '/api/brewing-parameters', params);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/brewing-parameters'] });
    }
  });

  // Save shot session mutation
  const saveSessionMutation = useMutation({
    mutationFn: async (session: InsertShotSession) => {
      const response = await apiRequest('POST', '/api/shot-sessions', session);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/shot-sessions'] });
      toast({
        title: "Shot Saved",
        description: "Your shot data has been saved successfully.",
      });
    }
  });

  const calculateQuality = () => {
    const analysis = calculateQualityScore(parameters);
    setCurrentAnalysis(analysis);
    toast({
      title: "Quality Calculated",
      description: `Your shot scored ${analysis.estimated_quality_score}/100`,
    });
  };

  const submitFeedback = async (feedback: {
    actual_score: number;
    tasting_notes: string;
    crema_quality: string;
    shot_rating: string;
  }) => {
    try {
      // First save the parameters
      const savedParams = await saveParametersMutation.mutateAsync(parameters as InsertBrewingParameters);
      
      // Then save the session with feedback
      const session: InsertShotSession = {
        session_id: new Date().toISOString(),
        parameter_id: savedParams.id,
        estimated_score: currentAnalysis?.estimated_quality_score || 0,
        actual_score: feedback.actual_score,
        tasting_notes: feedback.tasting_notes,
        crema_quality: feedback.crema_quality,
        shot_rating: feedback.shot_rating,
      };

      await saveSessionMutation.mutateAsync(session);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save shot data. Please try again.",
        variant: "destructive"
      });
    }
  };

  const loadShot = (sessionId: number) => {
    const session = shotSessions.find((s: ShotSession) => s.id === sessionId);
    if (session && session.parameter_id) {
      // In a real implementation, you'd fetch the parameters by ID
      toast({
        title: "Shot Loaded",
        description: "Shot parameters have been loaded into the form.",
      });
    }
  };

  const handleImportData = async (importedData: ExportData[]) => {
    try {
      for (const data of importedData) {
        // Save parameters
        const savedParams = await saveParametersMutation.mutateAsync(data.parameters as InsertBrewingParameters);
        
        // Save session
        const session: InsertShotSession = {
          session_id: data.session_id,
          parameter_id: savedParams.id,
          estimated_score: data.estimated_score,
          actual_score: data.user_feedback?.actual_score || null,
          tasting_notes: data.user_feedback?.tasting_notes || null,
          crema_quality: data.user_feedback?.crema_quality || null,
          shot_rating: data.user_feedback?.shot_rating || null,
        };

        await saveSessionMutation.mutateAsync(session);
      }
    } catch (error) {
      toast({
        title: "Import Failed",
        description: "Failed to import some data. Please try again.",
        variant: "destructive"
      });
    }
  };

  // Load data from localStorage on mount
  useEffect(() => {
    const savedData = localStorage.getItem('espressoExpressionData');
    if (savedData) {
      try {
        const parsed = JSON.parse(savedData);
        if (parsed.parameters) {
          setParameters({ ...getDefaultParameters(), ...parsed.parameters });
        }
        if (parsed.currentAnalysis) {
          setCurrentAnalysis(parsed.currentAnalysis);
        }
      } catch (error) {
        console.error('Failed to load saved data:', error);
      }
    }
  }, []);

  // Save data to localStorage whenever it changes
  useEffect(() => {
    const dataToSave = {
      parameters,
      currentAnalysis
    };
    localStorage.setItem('espressoExpressionData', JSON.stringify(dataToSave));
  }, [parameters, currentAnalysis]);

  return (
    <div className="min-h-screen bg-cream">
      {/* Header */}
      <header className="bg-coffee-dark text-cream shadow-lg">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Coffee className="text-crema text-2xl h-8 w-8" />
              <h1 className="text-2xl font-bold">Espresso Expression</h1>
              <span className="text-coffee-light text-sm font-medium">Professional Shot Quality Analyzer</span>
            </div>
            <div className="flex items-center space-x-4">
              <Button 
                variant="secondary"
                className="bg-coffee-medium hover:bg-coffee-light text-white"
              >
                <Download className="mr-2 h-4 w-4" />
                Export
              </Button>
              <Button 
                variant="secondary"
                className="bg-crema hover:bg-orange-600 text-white"
              >
                <Upload className="mr-2 h-4 w-4" />
                Import
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-6 py-8">
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
          {/* Parameter Input Form */}
          <div className="xl:col-span-2">
            <ParameterInputForm
              parameters={parameters}
              onParametersChange={setParameters}
              onCalculateQuality={calculateQuality}
            />
          </div>

          {/* Quality Analysis Panel */}
          <div className="space-y-6">
            <QualityAnalysisComponent
              analysis={currentAnalysis}
              onSubmitFeedback={submitFeedback}
            />
            
            <ImportExport
              sessions={shotSessions}
              parameters={brewingParamsList}
              onImportData={handleImportData}
            />
          </div>
        </div>

        {/* Shot History */}
        <div className="mt-12">
          <ShotHistory
            sessions={shotSessions}
            parameters={brewingParamsList}
            onLoadShot={loadShot}
          />
        </div>
      </div>
    </div>
  );
}
