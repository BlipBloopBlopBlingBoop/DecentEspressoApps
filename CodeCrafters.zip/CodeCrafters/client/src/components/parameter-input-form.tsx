import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Coffee, Cog, Wrench, Thermometer, User, Calculator } from "lucide-react";
import { BrewingParameters } from "@/lib/espresso-scoring";

interface ParameterInputFormProps {
  parameters: BrewingParameters;
  onParametersChange: (parameters: BrewingParameters) => void;
  onCalculateQuality: () => void;
}

export function ParameterInputForm({ parameters, onParametersChange, onCalculateQuality }: ParameterInputFormProps) {
  const updateParameter = (key: keyof BrewingParameters, value: any) => {
    onParametersChange({
      ...parameters,
      [key]: value
    });
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-3 text-coffee-dark">
          <Coffee className="h-6 w-6 text-coffee-medium" />
          Brewing Parameters
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="beans" className="w-full">
          <TabsList className="grid w-full grid-cols-5 mb-6">
            <TabsTrigger value="beans" className="flex items-center gap-2">
              <Coffee className="h-4 w-4" />
              Beans
            </TabsTrigger>
            <TabsTrigger value="grinder" className="flex items-center gap-2">
              <Cog className="h-4 w-4" />
              Grinder
            </TabsTrigger>
            <TabsTrigger value="machine" className="flex items-center gap-2">
              <Wrench className="h-4 w-4" />
              Machine
            </TabsTrigger>
            <TabsTrigger value="environment" className="flex items-center gap-2">
              <Thermometer className="h-4 w-4" />
              Environment
            </TabsTrigger>
            <TabsTrigger value="technique" className="flex items-center gap-2">
              <User className="h-4 w-4" />
              Technique
            </TabsTrigger>
          </TabsList>

          <TabsContent value="beans" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Moisture Content (%)</Label>
                <Slider
                  value={[parameters.moisture_content]}
                  onValueChange={(value) => updateParameter('moisture_content', value[0])}
                  max={15}
                  min={8}
                  step={0.1}
                  className="slider"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>8%</span>
                  <span className="font-medium">{parameters.moisture_content}%</span>
                  <span>15%</span>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label>Oil Level</Label>
                <Select value={parameters.oil_level} onValueChange={(value) => updateParameter('oil_level', value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Low">Low</SelectItem>
                    <SelectItem value="Medium">Medium</SelectItem>
                    <SelectItem value="High">High</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Roast Profile</Label>
                <Select value={parameters.roast_profile} onValueChange={(value) => updateParameter('roast_profile', value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Light">Light</SelectItem>
                    <SelectItem value="Medium">Medium</SelectItem>
                    <SelectItem value="Medium-Dark">Medium-Dark</SelectItem>
                    <SelectItem value="Dark">Dark</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Bean Density</Label>
                <Slider
                  value={[parameters.bean_density]}
                  onValueChange={(value) => updateParameter('bean_density', value[0])}
                  max={0.8}
                  min={0.6}
                  step={0.01}
                  className="slider"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>0.6</span>
                  <span className="font-medium">{parameters.bean_density}</span>
                  <span>0.8</span>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Bean Species</Label>
                <Select value={parameters.bean_species} onValueChange={(value) => updateParameter('bean_species', value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Arabica">Arabica</SelectItem>
                    <SelectItem value="Robusta">Robusta</SelectItem>
                    <SelectItem value="Blend">Blend</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Bean Age (Days)</Label>
                <Input
                  type="number"
                  value={parameters.bean_age_days}
                  onChange={(e) => updateParameter('bean_age_days', parseInt(e.target.value) || 0)}
                  min={1}
                  max={60}
                />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="grinder" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Grind Size (μm)</Label>
                <Slider
                  value={[parameters.grind_size_microns]}
                  onValueChange={(value) => updateParameter('grind_size_microns', value[0])}
                  max={400}
                  min={200}
                  step={5}
                  className="slider"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>200μm</span>
                  <span className="font-medium">{parameters.grind_size_microns}μm</span>
                  <span>400μm</span>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Burr Type</Label>
                <Select value={parameters.burr_type} onValueChange={(value) => updateParameter('burr_type', value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Flat">Flat</SelectItem>
                    <SelectItem value="Conical">Conical</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Burr Alignment</Label>
                <Select value={parameters.burr_alignment} onValueChange={(value) => updateParameter('burr_alignment', value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Aligned">Aligned</SelectItem>
                    <SelectItem value="Slightly Misaligned">Slightly Misaligned</SelectItem>
                    <SelectItem value="Misaligned">Misaligned</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Grinder RPM</Label>
                <Slider
                  value={[parameters.grinder_rpm]}
                  onValueChange={(value) => updateParameter('grinder_rpm', value[0])}
                  max={2000}
                  min={500}
                  step={50}
                  className="slider"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>500</span>
                  <span className="font-medium">{parameters.grinder_rpm}</span>
                  <span>2000</span>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Static Effect</Label>
                <Select value={parameters.static_effect} onValueChange={(value) => updateParameter('static_effect', value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Low">Low</SelectItem>
                    <SelectItem value="Moderate">Moderate</SelectItem>
                    <SelectItem value="High">High</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Retention (g)</Label>
                <Input
                  type="number"
                  value={parameters.retention_g}
                  onChange={(e) => updateParameter('retention_g', parseFloat(e.target.value) || 0)}
                  min={0}
                  max={2}
                  step={0.1}
                />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="machine" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Brew Pressure (bar)</Label>
                <Slider
                  value={[parameters.brew_pressure_bar]}
                  onValueChange={(value) => updateParameter('brew_pressure_bar', value[0])}
                  max={12}
                  min={6}
                  step={0.1}
                  className="slider"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>6 bar</span>
                  <span className="font-medium">{parameters.brew_pressure_bar} bar</span>
                  <span>12 bar</span>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Brew Temperature (°C)</Label>
                <Slider
                  value={[parameters.brew_temp_celsius]}
                  onValueChange={(value) => updateParameter('brew_temp_celsius', value[0])}
                  max={98}
                  min={85}
                  step={0.5}
                  className="slider"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>85°C</span>
                  <span className="font-medium">{parameters.brew_temp_celsius}°C</span>
                  <span>98°C</span>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Temperature Stability</Label>
                <Select value={parameters.temp_stability_score} onValueChange={(value) => updateParameter('temp_stability_score', value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Poor">Poor</SelectItem>
                    <SelectItem value="Good">Good</SelectItem>
                    <SelectItem value="Excellent">Excellent</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Flow Rate (g/s)</Label>
                <Slider
                  value={[parameters.flow_rate_g_per_sec]}
                  onValueChange={(value) => updateParameter('flow_rate_g_per_sec', value[0])}
                  max={4}
                  min={1}
                  step={0.1}
                  className="slider"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>1 g/s</span>
                  <span className="font-medium">{parameters.flow_rate_g_per_sec} g/s</span>
                  <span>4 g/s</span>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Water TDS (ppm)</Label>
                <Slider
                  value={[parameters.water_quality_tds_ppm]}
                  onValueChange={(value) => updateParameter('water_quality_tds_ppm', value[0])}
                  max={150}
                  min={50}
                  step={5}
                  className="slider"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>50</span>
                  <span className="font-medium">{parameters.water_quality_tds_ppm}</span>
                  <span>150</span>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Water pH</Label>
                <Slider
                  value={[parameters.water_pH]}
                  onValueChange={(value) => updateParameter('water_pH', value[0])}
                  max={8.0}
                  min={6.5}
                  step={0.1}
                  className="slider"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>6.5</span>
                  <span className="font-medium">{parameters.water_pH}</span>
                  <span>8.0</span>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="environment" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Ambient Temperature (°C)</Label>
                <Slider
                  value={[parameters.ambient_temp_celsius]}
                  onValueChange={(value) => updateParameter('ambient_temp_celsius', value[0])}
                  max={30}
                  min={15}
                  step={0.5}
                  className="slider"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>15°C</span>
                  <span className="font-medium">{parameters.ambient_temp_celsius}°C</span>
                  <span>30°C</span>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Humidity (%)</Label>
                <Slider
                  value={[parameters.humidity_percent]}
                  onValueChange={(value) => updateParameter('humidity_percent', value[0])}
                  max={80}
                  min={30}
                  step={1}
                  className="slider"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>30%</span>
                  <span className="font-medium">{parameters.humidity_percent}%</span>
                  <span>80%</span>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Altitude (m)</Label>
                <Input
                  type="number"
                  value={parameters.altitude_meters}
                  onChange={(e) => updateParameter('altitude_meters', parseFloat(e.target.value) || 0)}
                  min={0}
                  max={3000}
                  step={10}
                />
              </div>

              <div className="space-y-2">
                <Label>Barometric Pressure (kPa)</Label>
                <Slider
                  value={[parameters.barometric_pressure_kpa]}
                  onValueChange={(value) => updateParameter('barometric_pressure_kpa', value[0])}
                  max={105}
                  min={95}
                  step={0.1}
                  className="slider"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>95</span>
                  <span className="font-medium">{parameters.barometric_pressure_kpa}</span>
                  <span>105</span>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="technique" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Tamping Force (lbs)</Label>
                <Slider
                  value={[parameters.tamping_force_lbs]}
                  onValueChange={(value) => updateParameter('tamping_force_lbs', value[0])}
                  max={40}
                  min={20}
                  step={1}
                  className="slider"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>20 lbs</span>
                  <span className="font-medium">{parameters.tamping_force_lbs} lbs</span>
                  <span>40 lbs</span>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Distribution Method</Label>
                <Select value={parameters.distribution_method} onValueChange={(value) => updateParameter('distribution_method', value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="None">None</SelectItem>
                    <SelectItem value="Tap">Tap</SelectItem>
                    <SelectItem value="WDT">WDT</SelectItem>
                    <SelectItem value="Leveler">Leveler</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Dose (g)</Label>
                <Slider
                  value={[parameters.dose_grams]}
                  onValueChange={(value) => updateParameter('dose_grams', value[0])}
                  max={22}
                  min={15}
                  step={0.1}
                  className="slider"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>15g</span>
                  <span className="font-medium">{parameters.dose_grams}g</span>
                  <span>22g</span>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Shot Time (s)</Label>
                <Slider
                  value={[parameters.shot_time_sec]}
                  onValueChange={(value) => updateParameter('shot_time_sec', value[0])}
                  max={40}
                  min={20}
                  step={1}
                  className="slider"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>20s</span>
                  <span className="font-medium">{parameters.shot_time_sec}s</span>
                  <span>40s</span>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Yield (g)</Label>
                <Slider
                  value={[parameters.yield_grams]}
                  onValueChange={(value) => updateParameter('yield_grams', value[0])}
                  max={50}
                  min={25}
                  step={0.5}
                  className="slider"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>25g</span>
                  <span className="font-medium">{parameters.yield_grams}g</span>
                  <span>50g</span>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Brew Ratio</Label>
                <Slider
                  value={[parameters.brew_ratio]}
                  onValueChange={(value) => updateParameter('brew_ratio', value[0])}
                  max={3.0}
                  min={1.5}
                  step={0.1}
                  className="slider"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>1.5:1</span>
                  <span className="font-medium">{parameters.brew_ratio}:1</span>
                  <span>3.0:1</span>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        <div className="mt-8 flex justify-center">
          <Button 
            onClick={onCalculateQuality}
            className="bg-coffee-medium hover:bg-coffee-light text-white px-8 py-3 font-semibold"
          >
            <Calculator className="mr-2 h-4 w-4" />
            Calculate Shot Quality
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
