import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { History, RotateCcw } from "lucide-react";
import { ShotSession, BrewingParameters } from "@shared/schema";

interface ShotHistoryProps {
  sessions: ShotSession[];
  parameters: BrewingParameters[];
  onLoadShot: (sessionId: number) => void;
}

export function ShotHistory({ sessions, parameters, onLoadShot }: ShotHistoryProps) {
  const getParametersForSession = (session: ShotSession) => {
    return parameters.find(p => p.id === session.parameter_id);
  };

  const getScoreBadgeVariant = (score: number) => {
    if (score >= 90) return "default"; // green
    if (score >= 80) return "secondary"; // blue
    if (score >= 70) return "outline"; // yellow
    return "destructive"; // red
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString() + " " + new Date(date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const truncateNotes = (notes: string | null, maxLength: number = 50) => {
    if (!notes) return "-";
    return notes.length > maxLength ? notes.substring(0, maxLength) + "..." : notes;
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-3 text-coffee-dark">
          <History className="h-6 w-6 text-indigo-500" />
          Shot History
        </CardTitle>
      </CardHeader>
      <CardContent>
        {sessions.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            No shot history yet. Calculate and save your first shot!
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Estimated Score</TableHead>
                  <TableHead>Actual Score</TableHead>
                  <TableHead>Dose</TableHead>
                  <TableHead>Yield</TableHead>
                  <TableHead>Time</TableHead>
                  <TableHead>Notes</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {sessions.map((session) => {
                  const params = getParametersForSession(session);
                  return (
                    <TableRow key={session.id} className="hover:bg-muted/50">
                      <TableCell className="text-sm">
                        {formatDate(session.created_at)}
                      </TableCell>
                      <TableCell>
                        <Badge variant={getScoreBadgeVariant(session.estimated_score)}>
                          {session.estimated_score}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {session.actual_score ? (
                          <Badge variant={getScoreBadgeVariant(session.actual_score)}>
                            {session.actual_score}
                          </Badge>
                        ) : (
                          <span className="text-muted-foreground">-</span>
                        )}
                      </TableCell>
                      <TableCell>{params?.dose_grams || "-"}g</TableCell>
                      <TableCell>{params?.yield_grams || "-"}g</TableCell>
                      <TableCell>{params?.shot_time_sec || "-"}s</TableCell>
                      <TableCell className="max-w-xs">
                        <span className="text-sm text-muted-foreground">
                          {truncateNotes(session.tasting_notes)}
                        </span>
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => onLoadShot(session.id)}
                          className="h-8 w-8 p-0"
                        >
                          <RotateCcw className="h-4 w-4 text-coffee-medium" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
