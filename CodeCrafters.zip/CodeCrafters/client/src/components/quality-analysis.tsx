import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Star, TrendingUp, MessageSquare, Save, BarChart3, Clock } from "lucide-react";
import { QualityAnalysis } from "@/lib/espresso-scoring";
import { useState } from "react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';

interface QualityAnalysisProps {
  analysis: QualityAnalysis | null;
  onSubmitFeedback: (feedback: {
    actual_score: number;
    tasting_notes: string;
    crema_quality: string;
    shot_rating: string;
  }) => void;
}

export function QualityAnalysisComponent({ analysis, onSubmitFeedback }: QualityAnalysisProps) {
  const [actualScore, setActualScore] = useState(90);
  const [tastingNotes, setTastingNotes] = useState("");
  const [cremaQuality, setCremaQuality] = useState("");
  const [shotRating, setShotRating] = useState("");

  // Generate extraction curve data for visualization
  const generateExtractionData = () => {
    if (!analysis) return [];
    
    const data = [];
    for (let time = 0; time <= 35; time += 2) {
      // Simulate extraction rate curve based on brewing parameters
      let extractionRate = 0;
      if (time <= 5) {
        // Pre-infusion phase
        extractionRate = time * 0.02;
      } else if (time <= 25) {
        // Main extraction phase
        const baseRate = 0.18;
        const timeProgress = (time - 5) / 20;
        extractionRate = baseRate + (timeProgress * 0.04) - (Math.pow(timeProgress, 2) * 0.02);
      } else {
        // Over-extraction phase
        const overTime = time - 25;
        extractionRate = 0.20 + (overTime * 0.008);
      }
      
      data.push({
        time,
        extraction: Math.round(extractionRate * 100 * 100) / 100,
        optimal: time <= 30 ? (time >= 20 ? 20 : (time >= 5 ? 18 + ((time - 5) / 15) * 2 : 0)) : 22
      });
    }
    return data;
  };

  const handleSubmitFeedback = () => {
    onSubmitFeedback({
      actual_score: actualScore,
      tasting_notes: tastingNotes,
      crema_quality: cremaQuality,
      shot_rating: shotRating
    });
    
    // Reset form
    setTastingNotes("");
    setCremaQuality("");
    setShotRating("");
  };

  const getScoreColor = (score: number) => {
    if (score >= 90) return "text-green-600";
    if (score >= 80) return "text-blue-600";
    if (score >= 70) return "text-yellow-600";
    if (score >= 60) return "text-orange-600";
    return "text-red-600";
  };

  const getScoreLevel = (score: number) => {
    if (score >= 90) return "Exceptional";
    if (score >= 80) return "Excellent";
    if (score >= 70) return "Good";
    if (score >= 60) return "Fair";
    return "Needs Improvement";
  };

  return (
    <div className="space-y-6">
      {/* Quality Score Display */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-coffee-dark">
            <Star className="h-5 w-5 text-yellow-500" />
            Estimated Quality Score
          </CardTitle>
        </CardHeader>
        <CardContent>
          {analysis ? (
            <div className="text-center">
              <div className="relative w-32 h-32 mx-auto mb-4">
                <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 100 100">
                  <circle 
                    cx="50" 
                    cy="50" 
                    r="40" 
                    stroke="#E5E7EB" 
                    strokeWidth="8" 
                    fill="none"
                  />
                  <circle 
                    cx="50" 
                    cy="50" 
                    r="40" 
                    stroke="hsl(var(--coffee-medium))" 
                    strokeWidth="8" 
                    fill="none" 
                    strokeDasharray="251.2" 
                    strokeDashoffset={251.2 - (analysis.estimated_quality_score / 100) * 251.2}
                    className="transition-all duration-1000"
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className={`text-3xl font-bold ${getScoreColor(analysis.estimated_quality_score)}`}>
                    {analysis.estimated_quality_score}
                  </span>
                </div>
              </div>
              <div className="text-sm text-muted-foreground">out of 100</div>
              <div className={`font-medium mt-2 ${getScoreColor(analysis.estimated_quality_score)}`}>
                {getScoreLevel(analysis.estimated_quality_score)}
              </div>
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              Click "Calculate Shot Quality" to see your score
            </div>
          )}
        </CardContent>
      </Card>

      {/* Analysis & Recommendations */}
      {analysis && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-coffee-dark">
              <TrendingUp className="h-5 w-5 text-blue-500" />
              Analysis & Recommendations
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <p className="text-sm text-foreground leading-relaxed">
                {analysis.analysis}
              </p>
              
              {analysis.recommendations.length > 0 && (
                <div className="bg-blue-50 dark:bg-blue-950 rounded-lg p-4 border-l-4 border-blue-400">
                  <h4 className="font-medium text-blue-800 dark:text-blue-200 mb-2">
                    💡 Optimization Tips
                  </h4>
                  <ul className="text-blue-700 dark:text-blue-300 text-sm space-y-1">
                    {analysis.recommendations.map((rec, index) => (
                      <li key={index}>• {rec}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Extraction Rate Chart */}
      {analysis && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-coffee-dark">
              <BarChart3 className="h-5 w-5 text-green-500" />
              Extraction Rate Prediction
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={generateExtractionData()}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="time" 
                    label={{ value: 'Time (seconds)', position: 'insideBottom', offset: -10 }}
                  />
                  <YAxis 
                    label={{ value: 'Extraction %', angle: -90, position: 'insideLeft' }}
                  />
                  <Tooltip 
                    formatter={(value: any, name: string) => [
                      `${value}%`, 
                      name === 'extraction' ? 'Predicted' : 'Optimal Range'
                    ]}
                    labelFormatter={(label) => `Time: ${label}s`}
                  />
                  <ReferenceLine y={18} stroke="#22c55e" strokeDasharray="5 5" />
                  <ReferenceLine y={22} stroke="#22c55e" strokeDasharray="5 5" />
                  <Line 
                    type="monotone" 
                    dataKey="extraction" 
                    stroke="hsl(var(--coffee-medium))" 
                    strokeWidth={3}
                    dot={{ fill: 'hsl(var(--coffee-medium))', strokeWidth: 2, r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-4 grid grid-cols-3 gap-4 text-center">
              <div className="bg-green-50 dark:bg-green-950 p-3 rounded">
                <div className="text-green-700 dark:text-green-300 font-medium">Target Zone</div>
                <div className="text-sm text-green-600 dark:text-green-400">18-22%</div>
              </div>
              <div className="bg-coffee-100 p-3 rounded">
                <div className="text-coffee-dark font-medium">Optimal Time</div>
                <div className="text-sm text-coffee-medium">25-30s</div>
              </div>
              <div className="bg-orange-50 dark:bg-orange-950 p-3 rounded">
                <div className="text-orange-700 dark:text-orange-300 font-medium">Risk Zone</div>
                <div className="text-sm text-orange-600 dark:text-orange-400">&gt;30s</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* User Feedback Form */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-coffee-dark">
            <MessageSquare className="h-5 w-5 text-purple-500" />
            Rate Your Shot
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Actual Quality (0-100)</Label>
            <Slider
              value={[actualScore]}
              onValueChange={(value) => setActualScore(value[0])}
              max={100}
              min={0}
              step={1}
              className="slider"
            />
            <div className="text-center">
              <span className="font-medium text-lg">{actualScore}</span>
            </div>
          </div>
          
          <div className="space-y-2">
            <Label>Tasting Notes</Label>
            <Textarea
              placeholder="Describe the taste, aroma, and overall experience..."
              value={tastingNotes}
              onChange={(e) => setTastingNotes(e.target.value)}
              className="resize-none"
              rows={3}
            />
          </div>
          
          <div className="space-y-2">
            <Label>Crema Quality</Label>
            <Select value={cremaQuality} onValueChange={setCremaQuality}>
              <SelectTrigger>
                <SelectValue placeholder="Select crema quality" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Poor">Poor</SelectItem>
                <SelectItem value="Fair">Fair</SelectItem>
                <SelectItem value="Good">Good</SelectItem>
                <SelectItem value="High">High</SelectItem>
                <SelectItem value="Excellent">Excellent</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Shot Rating</Label>
            <Select value={shotRating} onValueChange={setShotRating}>
              <SelectTrigger>
                <SelectValue placeholder="Overall rating" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Poor">Poor</SelectItem>
                <SelectItem value="Fair">Fair</SelectItem>
                <SelectItem value="Good">Good</SelectItem>
                <SelectItem value="Excellent">Excellent</SelectItem>
                <SelectItem value="Perfect">Perfect</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <Button 
            onClick={handleSubmitFeedback}
            className="w-full bg-purple-600 hover:bg-purple-700 text-white"
          >
            <Save className="mr-2 h-4 w-4" />
            Save Shot Data
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
