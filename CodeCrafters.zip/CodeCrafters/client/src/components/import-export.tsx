import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Upload, Download, FileText, Database } from "lucide-react";
import { ShotSession, BrewingParameters } from "@shared/schema";
import { exportAsJSON, exportAsCSV, downloadFile, parseImportedJSON, parseImportedCSV, ExportData } from "@/lib/data-export";
import { useToast } from "@/hooks/use-toast";

interface ImportExportProps {
  sessions: ShotSession[];
  parameters: BrewingParameters[];
  onImportData: (data: ExportData[]) => void;
}

export function ImportExport({ sessions, parameters, onImportData }: ImportExportProps) {
  const [exportFormat, setExportFormat] = useState<"json" | "csv">("json");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { toast } = useToast();

  const handleExport = () => {
    try {
      if (sessions.length === 0) {
        toast({
          title: "No Data to Export",
          description: "You need to have at least one shot session to export data.",
          variant: "destructive"
        });
        return;
      }

      const timestamp = new Date().toISOString().split('T')[0];
      
      if (exportFormat === "json") {
        const jsonData = exportAsJSON(sessions, parameters);
        downloadFile(jsonData, `espresso-profile-${timestamp}.json`, 'application/json');
        toast({
          title: "Export Successful",
          description: "Profile exported as JSON file.",
        });
      } else {
        const csvData = exportAsCSV(sessions, parameters);
        downloadFile(csvData, `espresso-data-${timestamp}.csv`, 'text/csv');
        toast({
          title: "Export Successful",
          description: "Data exported as CSV file.",
        });
      }
      
      setIsDialogOpen(false);
    } catch (error) {
      toast({
        title: "Export Failed",
        description: "There was an error exporting your data. Please try again.",
        variant: "destructive"
      });
    }
  };

  const handleFileImport = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        let importedData: ExportData[];

        if (file.name.endsWith('.json')) {
          importedData = parseImportedJSON(content);
        } else if (file.name.endsWith('.csv')) {
          importedData = parseImportedCSV(content);
        } else {
          throw new Error("Unsupported file format. Please use JSON or CSV files.");
        }

        onImportData(importedData);
        setIsDialogOpen(false);
        toast({
          title: "Import Successful",
          description: `Successfully imported ${importedData.length} shot session(s).`,
        });
      } catch (error) {
        toast({
          title: "Import Failed",
          description: error instanceof Error ? error.message : "Failed to parse file",
          variant: "destructive"
        });
      }
    };

    reader.readAsText(file);
    event.target.value = ''; // Reset file input
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-coffee-dark">
          <Database className="h-5 w-5 text-blue-500" />
          Data Management
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button variant="outline" className="w-full">
              <Upload className="mr-2 h-4 w-4" />
              Import Profile
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Import/Export Data</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Export Format</Label>
                <Select value={exportFormat} onValueChange={(value: "json" | "csv") => setExportFormat(value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="json">JSON</SelectItem>
                    <SelectItem value="csv">CSV</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex space-x-3">
                <Button 
                  onClick={handleExport}
                  className="flex-1 bg-coffee-medium hover:bg-coffee-light text-white"
                >
                  <Download className="mr-2 h-4 w-4" />
                  Export
                </Button>
              </div>
              
              <div className="space-y-2">
                <Label>Import File</Label>
                <Input
                  type="file"
                  accept=".json,.csv"
                  onChange={handleFileImport}
                  className="text-sm"
                />
                <p className="text-xs text-muted-foreground">
                  Supports JSON and CSV files exported from Espresso Expression
                </p>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        <Button 
          onClick={() => {
            setExportFormat("json");
            handleExport();
          }}
          variant="outline" 
          className="w-full bg-coffee-100 hover:bg-coffee-200 text-coffee-dark"
        >
          <FileText className="mr-2 h-4 w-4" />
          Quick Export JSON
        </Button>

        <Button 
          onClick={() => {
            setExportFormat("csv");
            handleExport();
          }}
          variant="outline" 
          className="w-full bg-coffee-100 hover:bg-coffee-200 text-coffee-dark"
        >
          <FileText className="mr-2 h-4 w-4" />
          Quick Export CSV
        </Button>
      </CardContent>
    </Card>
  );
}
