import { ShotSession, BrewingParameters } from "@shared/schema";

export interface ExportData {
  session_id: string;
  parameters: BrewingParameters;
  estimated_score: number;
  user_feedback?: {
    actual_score?: number;
    tasting_notes?: string;
    crema_quality?: string;
    shot_rating?: string;
  };
  created_at: string;
}

export function exportAsJSON(sessions: ShotSession[], parameters: BrewingParameters[]): string {
  const exportData: ExportData[] = sessions.map(session => {
    const params = parameters.find(p => p.id === session.parameter_id);
    return {
      session_id: session.session_id,
      parameters: params || {} as BrewingParameters,
      estimated_score: session.estimated_score,
      user_feedback: {
        actual_score: session.actual_score || undefined,
        tasting_notes: session.tasting_notes || undefined,
        crema_quality: session.crema_quality || undefined,
        shot_rating: session.shot_rating || undefined,
      },
      created_at: session.created_at.toISOString(),
    };
  });

  return JSON.stringify(exportData, null, 2);
}

export function exportAsCSV(sessions: ShotSession[], parameters: BrewingParameters[]): string {
  const headers = [
    'session_id',
    'created_at',
    'estimated_score',
    'actual_score',
    'tasting_notes',
    'crema_quality',
    'shot_rating',
    // Bean Properties
    'moisture_content',
    'oil_level',
    'roast_profile',
    'bean_density',
    'bean_species',
    'bean_age_days',
    'storage_condition',
    // Grinder Settings
    'grind_size_microns',
    'burr_type',
    'burr_alignment',
    'burr_material',
    'grinder_rpm',
    'static_effect',
    'retention_g',
    'grind_heat_celsius',
    // Machine Parameters
    'brew_pressure_bar',
    'brew_temp_celsius',
    'temp_stability_score',
    'flow_rate_g_per_sec',
    'preinfusion_sec',
    'boiler_type',
    'pump_type',
    'basket_type',
    'water_quality_tds_ppm',
    'water_pH',
    // Environment
    'ambient_temp_celsius',
    'humidity_percent',
    'altitude_meters',
    'barometric_pressure_kpa',
    // Barista Technique
    'tamping_force_lbs',
    'tamping_consistency',
    'distribution_method',
    'dose_grams',
    'shot_time_sec',
    'yield_grams',
    'brew_ratio'
  ];

  const csvData = [headers.join(',')];

  sessions.forEach(session => {
    const params = parameters.find(p => p.id === session.parameter_id);
    const row = [
      session.session_id,
      session.created_at.toISOString(),
      session.estimated_score,
      session.actual_score || '',
      `"${(session.tasting_notes || '').replace(/"/g, '""')}"`,
      session.crema_quality || '',
      session.shot_rating || '',
      // Bean Properties
      params?.moisture_content || '',
      params?.oil_level || '',
      params?.roast_profile || '',
      params?.bean_density || '',
      params?.bean_species || '',
      params?.bean_age_days || '',
      params?.storage_condition || '',
      // Grinder Settings
      params?.grind_size_microns || '',
      params?.burr_type || '',
      params?.burr_alignment || '',
      params?.burr_material || '',
      params?.grinder_rpm || '',
      params?.static_effect || '',
      params?.retention_g || '',
      params?.grind_heat_celsius || '',
      // Machine Parameters
      params?.brew_pressure_bar || '',
      params?.brew_temp_celsius || '',
      params?.temp_stability_score || '',
      params?.flow_rate_g_per_sec || '',
      params?.preinfusion_sec || '',
      params?.boiler_type || '',
      params?.pump_type || '',
      params?.basket_type || '',
      params?.water_quality_tds_ppm || '',
      params?.water_pH || '',
      // Environment
      params?.ambient_temp_celsius || '',
      params?.humidity_percent || '',
      params?.altitude_meters || '',
      params?.barometric_pressure_kpa || '',
      // Barista Technique
      params?.tamping_force_lbs || '',
      params?.tamping_consistency || '',
      params?.distribution_method || '',
      params?.dose_grams || '',
      params?.shot_time_sec || '',
      params?.yield_grams || '',
      params?.brew_ratio || ''
    ];
    csvData.push(row.join(','));
  });

  return csvData.join('\n');
}

export function downloadFile(content: string, filename: string, contentType: string): void {
  const blob = new Blob([content], { type: contentType });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function parseImportedJSON(jsonString: string): ExportData[] {
  try {
    const data = JSON.parse(jsonString);
    if (Array.isArray(data)) {
      return data;
    } else if (data.session_id) {
      return [data];
    }
    throw new Error("Invalid JSON format");
  } catch (error) {
    throw new Error("Failed to parse JSON file");
  }
}

export function parseImportedCSV(csvString: string): ExportData[] {
  const lines = csvString.trim().split('\n');
  if (lines.length < 2) {
    throw new Error("CSV file must contain headers and at least one data row");
  }

  const headers = lines[0].split(',');
  const data: ExportData[] = [];

  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].split(',');
    const row: any = {};
    
    headers.forEach((header, index) => {
      const value = values[index]?.replace(/^"(.*)"$/, '$1').replace(/""/g, '"');
      row[header.trim()] = value || null;
    });

    // Convert to ExportData format
    const exportData: ExportData = {
      session_id: row.session_id,
      parameters: {
        id: 0, // Will be assigned when saved
        moisture_content: parseFloat(row.moisture_content) || 10.5,
        oil_level: row.oil_level || "Medium",
        roast_profile: row.roast_profile || "Medium",
        bean_density: parseFloat(row.bean_density) || 0.72,
        bean_species: row.bean_species || "Arabica",
        bean_age_days: parseInt(row.bean_age_days) || 7,
        storage_condition: row.storage_condition || "Room temperature",
        grind_size_microns: parseInt(row.grind_size_microns) || 250,
        burr_type: row.burr_type || "Flat",
        burr_alignment: row.burr_alignment || "Aligned",
        burr_material: row.burr_material || "Steel",
        grinder_rpm: parseInt(row.grinder_rpm) || 1350,
        static_effect: row.static_effect || "Moderate",
        retention_g: parseFloat(row.retention_g) || 0.5,
        grind_heat_celsius: parseFloat(row.grind_heat_celsius) || 35,
        brew_pressure_bar: parseFloat(row.brew_pressure_bar) || 9,
        brew_temp_celsius: parseFloat(row.brew_temp_celsius) || 94,
        temp_stability_score: row.temp_stability_score || "Good",
        flow_rate_g_per_sec: parseFloat(row.flow_rate_g_per_sec) || 2.2,
        preinfusion_sec: parseFloat(row.preinfusion_sec) || 5,
        boiler_type: row.boiler_type || "Single",
        pump_type: row.pump_type || "Vibratory",
        basket_type: row.basket_type || "Standard",
        water_quality_tds_ppm: parseInt(row.water_quality_tds_ppm) || 75,
        water_pH: parseFloat(row.water_pH) || 7.0,
        ambient_temp_celsius: parseFloat(row.ambient_temp_celsius) || 22,
        humidity_percent: parseFloat(row.humidity_percent) || 55,
        altitude_meters: parseFloat(row.altitude_meters) || 300,
        barometric_pressure_kpa: parseFloat(row.barometric_pressure_kpa) || 101.3,
        tamping_force_lbs: parseFloat(row.tamping_force_lbs) || 30,
        tamping_consistency: row.tamping_consistency || "Medium",
        distribution_method: row.distribution_method || "WDT",
        dose_grams: parseFloat(row.dose_grams) || 18,
        shot_time_sec: parseFloat(row.shot_time_sec) || 28,
        yield_grams: parseFloat(row.yield_grams) || 36,
        brew_ratio: parseFloat(row.brew_ratio) || 2.0
      },
      estimated_score: parseInt(row.estimated_score) || 0,
      user_feedback: {
        actual_score: row.actual_score ? parseInt(row.actual_score) : undefined,
        tasting_notes: row.tasting_notes || undefined,
        crema_quality: row.crema_quality || undefined,
        shot_rating: row.shot_rating || undefined,
      },
      created_at: row.created_at || new Date().toISOString()
    };

    data.push(exportData);
  }

  return data;
}
