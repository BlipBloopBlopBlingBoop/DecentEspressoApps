export interface BrewingParameters {
  // Bean Properties
  moisture_content: number;
  oil_level: string;
  roast_profile: string;
  bean_density: number;
  bean_species: string;
  bean_age_days: number;
  storage_condition: string;
  
  // Grinder Settings
  grind_size_microns: number;
  burr_type: string;
  burr_alignment: string;
  burr_material: string;
  grinder_rpm: number;
  static_effect: string;
  retention_g: number;
  grind_heat_celsius: number;
  
  // Machine Parameters
  brew_pressure_bar: number;
  brew_temp_celsius: number;
  temp_stability_score: string;
  flow_rate_g_per_sec: number;
  preinfusion_sec: number;
  boiler_type: string;
  pump_type: string;
  basket_type: string;
  water_quality_tds_ppm: number;
  water_pH: number;
  
  // Environment
  ambient_temp_celsius: number;
  humidity_percent: number;
  altitude_meters: number;
  barometric_pressure_kpa: number;
  
  // Barista Technique
  tamping_force_lbs: number;
  tamping_consistency: string;
  distribution_method: string;
  dose_grams: number;
  shot_time_sec: number;
  yield_grams: number;
  brew_ratio: number;
}

export interface QualityAnalysis {
  estimated_quality_score: number;
  analysis: string;
  recommendations: string[];
}

export function calculateQualityScore(params: BrewingParameters): QualityAnalysis {
  let score = 0; // Start from 0 for more realistic scoring
  const recommendations: string[] = [];
  const penalties: number[] = [];
  
  // Calculate extraction rate prediction
  const extractionRate = calculateExtractionRate(params);
  const extractionScore = getExtractionScore(extractionRate, recommendations, penalties);
  
  // Bean quality assessment (0-25 points)
  const beanScore = calculateBeanScore(params, recommendations, penalties);
  
  // Grinder performance (0-25 points)
  const grinderScore = calculateGrinderScore(params, recommendations, penalties);
  
  // Machine precision (0-25 points)
  const machineScore = calculateMachineScore(params, recommendations, penalties);
  
  // Technique consistency (0-25 points)
  const techniqueScore = calculateTechniqueScore(params, recommendations, penalties);
  
  // Apply penalty system for critical issues
  const totalPenalty = penalties.reduce((sum, penalty) => sum + penalty, 0);
  
  score = Math.max(0, extractionScore + beanScore + grinderScore + machineScore + techniqueScore - totalPenalty);
  
  const finalScore = Math.min(100, Math.max(0, Math.round(score)));
  
  // Generate detailed analysis
  const analysis = generateAnalysis(finalScore, extractionRate, params, recommendations);
  
  return {
    estimated_quality_score: finalScore,
    analysis,
    recommendations: recommendations.slice(0, 5) // Limit to top 5 recommendations
  };
}

function calculateExtractionRate(params: BrewingParameters): number {
  // Scientific extraction rate calculation based on brewing parameters
  const baseExtraction = 0.18; // Base extraction rate (18%)
  
  // Temperature effect (higher temp = higher extraction)
  const tempEffect = (params.brew_temp_celsius - 90) * 0.002;
  
  // Pressure effect
  const pressureEffect = (params.brew_pressure_bar - 9) * 0.01;
  
  // Grind size effect (finer = higher extraction)
  const grindEffect = (280 - params.grind_size_microns) * 0.0001;
  
  // Time effect
  const timeEffect = (params.shot_time_sec - 25) * 0.002;
  
  // Water chemistry effect
  const waterEffect = (params.water_quality_tds_ppm - 100) * 0.00005;
  
  return Math.max(0.12, Math.min(0.28, baseExtraction + tempEffect + pressureEffect + grindEffect + timeEffect + waterEffect));
}

function getExtractionScore(extractionRate: number, recommendations: string[], penalties: number[]): number {
  // Optimal extraction range is 18-22%
  if (extractionRate >= 0.18 && extractionRate <= 0.22) {
    return 25;
  } else if (extractionRate >= 0.16 && extractionRate <= 0.24) {
    return 20;
  } else if (extractionRate >= 0.14 && extractionRate <= 0.26) {
    return 15;
    if (extractionRate < 0.18) {
      recommendations.push("Under-extraction detected - consider finer grind or higher temperature");
    } else {
      recommendations.push("Over-extraction risk - consider coarser grind or lower temperature");
    }
  } else {
    penalties.push(5);
    if (extractionRate < 0.14) {
      recommendations.push("Severe under-extraction - major adjustments needed");
    } else {
      recommendations.push("Severe over-extraction risk - reduce extraction parameters");
    }
    return 5;
  }
}

function calculateBeanScore(params: BrewingParameters, recommendations: string[], penalties: number[]): number {
  let score = 0;
  
  // Bean age scoring (fresher is better)
  if (params.bean_age_days <= 7) {
    score += 8;
  } else if (params.bean_age_days <= 14) {
    score += 6;
  } else if (params.bean_age_days <= 21) {
    score += 4;
    recommendations.push("Beans are getting stale - consider fresher beans for peak flavor");
  } else {
    score += 1;
    penalties.push(3);
    recommendations.push("Beans are too old - use beans within 2-3 weeks of roast date");
  }
  
  // Moisture content
  if (params.moisture_content >= 10.5 && params.moisture_content <= 11.5) {
    score += 6;
  } else if (params.moisture_content >= 10 && params.moisture_content <= 12) {
    score += 4;
  } else {
    score += 1;
    recommendations.push("Moisture content outside optimal range affects extraction consistency");
  }
  
  // Bean density
  if (params.bean_density >= 0.70 && params.bean_density <= 0.75) {
    score += 5;
  } else {
    score += 2;
  }
  
  // Storage condition impact
  if (params.storage_condition.includes("Vacuum") || params.storage_condition.includes("cool")) {
    score += 3;
  } else {
    score += 1;
    recommendations.push("Proper storage (vacuum-sealed, cool) preserves bean quality");
  }
  
  // Roast profile vs grind size compatibility
  if ((params.roast_profile === "Light" && params.grind_size_microns <= 240) ||
      (params.roast_profile === "Medium" && params.grind_size_microns >= 240 && params.grind_size_microns <= 280) ||
      (params.roast_profile === "Dark" && params.grind_size_microns >= 270)) {
    score += 3;
  } else {
    recommendations.push("Adjust grind size to match roast profile for optimal extraction");
  }
  
  return Math.min(25, score);
}

function calculateGrinderScore(params: BrewingParameters, recommendations: string[], penalties: number[]): number {
  let score = 0;
  
  // Burr type and material
  if (params.burr_type === "Flat" && params.burr_material === "Steel") {
    score += 6;
  } else if (params.burr_type === "Conical" && params.burr_material === "Ceramic") {
    score += 5;
  } else {
    score += 3;
  }
  
  // Burr alignment is critical
  if (params.burr_alignment === "Aligned") {
    score += 8;
  } else if (params.burr_alignment === "Slightly Misaligned") {
    score += 3;
    recommendations.push("Burr misalignment causes uneven particle distribution");
  } else {
    penalties.push(5);
    recommendations.push("Severe burr misalignment - professional alignment needed");
  }
  
  // Grinder RPM (lower is better for heat control)
  if (params.grinder_rpm <= 1200) {
    score += 5;
  } else if (params.grinder_rpm <= 1500) {
    score += 3;
  } else {
    score += 1;
    recommendations.push("High RPM generates heat that degrades coffee oils");
  }
  
  // Static control
  if (params.static_effect === "Low") {
    score += 4;
  } else if (params.static_effect === "Moderate") {
    score += 2;
  } else {
    score += 0;
    recommendations.push("High static causes uneven distribution and channeling");
  }
  
  // Retention and heat buildup
  if (params.retention_g <= 0.3 && params.grind_heat_celsius <= 30) {
    score += 2;
  } else if (params.retention_g <= 0.8 && params.grind_heat_celsius <= 40) {
    score += 1;
  } else {
    recommendations.push("High retention or heat buildup affects grind consistency");
  }
  
  return Math.min(25, score);
}

function calculateMachineScore(params: BrewingParameters, recommendations: string[], penalties: number[]): number {
  let score = 0;
  
  // Pressure precision
  if (params.brew_pressure_bar >= 8.8 && params.brew_pressure_bar <= 9.2) {
    score += 8;
  } else if (params.brew_pressure_bar >= 8.5 && params.brew_pressure_bar <= 9.5) {
    score += 6;
  } else {
    score += 2;
    recommendations.push("Pressure outside optimal 8.8-9.2 bar range affects extraction");
  }
  
  // Temperature stability
  if (params.temp_stability_score === "Excellent" && 
      params.brew_temp_celsius >= 93 && params.brew_temp_celsius <= 95) {
    score += 8;
  } else if (params.temp_stability_score === "Good") {
    score += 5;
  } else {
    score += 2;
    penalties.push(2);
    recommendations.push("Temperature instability causes inconsistent extraction");
  }
  
  // Water quality
  if (params.water_quality_tds_ppm >= 75 && params.water_quality_tds_ppm <= 120 &&
      params.water_pH >= 6.9 && params.water_pH <= 7.1) {
    score += 6;
  } else {
    score += 2;
    recommendations.push("Water chemistry outside optimal range affects taste clarity");
  }
  
  // Flow rate consistency
  if (params.flow_rate_g_per_sec >= 2.0 && params.flow_rate_g_per_sec <= 2.5) {
    score += 3;
  } else {
    score += 1;
    recommendations.push("Flow rate affects extraction uniformity");
  }
  
  return Math.min(25, score);
}

function calculateTechniqueScore(params: BrewingParameters, recommendations: string[], penalties: number[]): number {
  let score = 0;
  
  // Dose consistency and basket compatibility
  if ((params.basket_type.includes("18g") && params.dose_grams >= 17.5 && params.dose_grams <= 18.5) ||
      (params.basket_type.includes("20g") && params.dose_grams >= 19.5 && params.dose_grams <= 20.5)) {
    score += 6;
  } else {
    score += 2;
    recommendations.push("Dose should match basket capacity for even extraction");
  }
  
  // Brew ratio precision
  const ratio = params.yield_grams / params.dose_grams;
  if (ratio >= 1.9 && ratio <= 2.1) {
    score += 8;
  } else if (ratio >= 1.7 && ratio <= 2.3) {
    score += 5;
  } else {
    score += 1;
    if (ratio < 1.7) {
      recommendations.push("Ratio too low - ristretto may be under-extracted");
    } else {
      recommendations.push("Ratio too high - lungo may be over-extracted");
    }
  }
  
  // Shot timing
  if (params.shot_time_sec >= 27 && params.shot_time_sec <= 30) {
    score += 6;
  } else if (params.shot_time_sec >= 25 && params.shot_time_sec <= 32) {
    score += 4;
  } else {
    score += 1;
    if (params.shot_time_sec < 25) {
      recommendations.push("Shot too fast - adjust grind finer or increase dose");
    } else {
      recommendations.push("Shot too slow - adjust grind coarser or decrease dose");
    }
  }
  
  // Tamping consistency
  if (params.tamping_consistency === "High" && 
      params.tamping_force_lbs >= 28 && params.tamping_force_lbs <= 32) {
    score += 3;
  } else {
    score += 1;
    recommendations.push("Consistent tamping pressure is crucial for even extraction");
  }
  
  // Distribution method
  if (params.distribution_method === "WDT" || params.distribution_method.includes("RDT")) {
    score += 2;
  } else {
    score += 1;
  }
  
  return Math.min(25, score);
}

function generateAnalysis(score: number, extractionRate: number, params: BrewingParameters, recommendations: string[]): string {
  let level = "";
  if (score >= 85) level = "Exceptional brewing setup";
  else if (score >= 75) level = "Professional-grade parameters";
  else if (score >= 65) level = "Good foundation with refinement opportunities";
  else if (score >= 50) level = "Decent setup requiring several adjustments";
  else level = "Multiple critical issues need immediate attention";
  
  const extractionPercent = Math.round(extractionRate * 100);
  const ratio = Math.round((params.yield_grams / params.dose_grams) * 10) / 10;
  
  return `${level}. Predicted extraction rate: ${extractionPercent}% (optimal: 18-22%). ` +
         `Current brew ratio: 1:${ratio}. Shot timing: ${params.shot_time_sec}s. ` +
         `${recommendations.length > 0 ? 'Priority improvements needed.' : 'Parameters well-optimized.'}`;
}

export function getDefaultParameters(): BrewingParameters {
  return {
    // Bean Properties
    moisture_content: 10.5,
    oil_level: "High",
    roast_profile: "Medium",
    bean_density: 0.72,
    bean_species: "Arabica",
    bean_age_days: 7,
    storage_condition: "Vacuum-sealed, cool",
    
    // Grinder Settings
    grind_size_microns: 250,
    burr_type: "Flat",
    burr_alignment: "Aligned",
    burr_material: "Steel",
    grinder_rpm: 1350,
    static_effect: "Moderate",
    retention_g: 0.5,
    grind_heat_celsius: 35,
    
    // Machine Parameters
    brew_pressure_bar: 9,
    brew_temp_celsius: 94,
    temp_stability_score: "Excellent",
    flow_rate_g_per_sec: 2.2,
    preinfusion_sec: 5,
    boiler_type: "Dual",
    pump_type: "Rotary",
    basket_type: "VST 18g",
    water_quality_tds_ppm: 75,
    water_pH: 7.0,
    
    // Environment
    ambient_temp_celsius: 22,
    humidity_percent: 55,
    altitude_meters: 300,
    barometric_pressure_kpa: 101.3,
    
    // Barista Technique
    tamping_force_lbs: 30,
    tamping_consistency: "High",
    distribution_method: "WDT",
    dose_grams: 18.0,
    shot_time_sec: 28,
    yield_grams: 36,
    brew_ratio: 2.0
  };
}
