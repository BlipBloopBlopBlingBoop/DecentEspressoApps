import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertBrewingParametersSchema, insertShotSessionSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Brewing Parameters routes
  app.post("/api/brewing-parameters", async (req, res) => {
    try {
      const validatedData = insertBrewingParametersSchema.parse(req.body);
      const brewingParam = await storage.createBrewingParameters(validatedData);
      res.json(brewingParam);
    } catch (error) {
      res.status(400).json({ message: "Invalid brewing parameters data", error });
    }
  });

  app.get("/api/brewing-parameters/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const brewingParam = await storage.getBrewingParameters(id);
      
      if (!brewingParam) {
        return res.status(404).json({ message: "Brewing parameters not found" });
      }
      
      res.json(brewingParam);
    } catch (error) {
      res.status(500).json({ message: "Error retrieving brewing parameters", error });
    }
  });

  app.get("/api/brewing-parameters", async (req, res) => {
    try {
      const brewingParams = await storage.getAllBrewingParameters();
      res.json(brewingParams);
    } catch (error) {
      res.status(500).json({ message: "Error retrieving brewing parameters", error });
    }
  });

  // Shot Sessions routes
  app.post("/api/shot-sessions", async (req, res) => {
    try {
      const validatedData = insertShotSessionSchema.parse(req.body);
      const shotSession = await storage.createShotSession(validatedData);
      res.json(shotSession);
    } catch (error) {
      res.status(400).json({ message: "Invalid shot session data", error });
    }
  });

  app.get("/api/shot-sessions", async (req, res) => {
    try {
      const sessions = await storage.getShotSessions();
      res.json(sessions);
    } catch (error) {
      res.status(500).json({ message: "Error retrieving shot sessions", error });
    }
  });

  app.get("/api/shot-sessions/by-parameters/:parameterId", async (req, res) => {
    try {
      const parameterId = parseInt(req.params.parameterId);
      const sessions = await storage.getShotSessionsByParameterId(parameterId);
      res.json(sessions);
    } catch (error) {
      res.status(500).json({ message: "Error retrieving shot sessions", error });
    }
  });

  app.patch("/api/shot-sessions/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const updatedSession = await storage.updateShotSession(id, updates);
      
      if (!updatedSession) {
        return res.status(404).json({ message: "Shot session not found" });
      }
      
      res.json(updatedSession);
    } catch (error) {
      res.status(500).json({ message: "Error updating shot session", error });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
