import { brewingParameters, shotSessions, type BrewingParameters, type InsertBrewingParameters, type ShotSession, type InsertShotSession } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  // Brewing Parameters
  createBrewingParameters(params: InsertBrewingParameters): Promise<BrewingParameters>;
  getBrewingParameters(id: number): Promise<BrewingParameters | undefined>;
  getAllBrewingParameters(): Promise<BrewingParameters[]>;
  
  // Shot Sessions
  createShotSession(session: InsertShotSession): Promise<ShotSession>;
  getShotSessions(): Promise<ShotSession[]>;
  getShotSessionsByParameterId(parameterId: number): Promise<ShotSession[]>;
  updateShotSession(id: number, updates: Partial<InsertShotSession>): Promise<ShotSession | undefined>;
}

export class DatabaseStorage implements IStorage {
  async createBrewingParameters(params: InsertBrewingParameters): Promise<BrewingParameters> {
    const [brewingParam] = await db
      .insert(brewingParameters)
      .values(params)
      .returning();
    return brewingParam;
  }

  async getBrewingParameters(id: number): Promise<BrewingParameters | undefined> {
    const [brewingParam] = await db
      .select()
      .from(brewingParameters)
      .where(eq(brewingParameters.id, id));
    return brewingParam || undefined;
  }

  async getAllBrewingParameters(): Promise<BrewingParameters[]> {
    return await db.select().from(brewingParameters);
  }

  async createShotSession(session: InsertShotSession): Promise<ShotSession> {
    const [shotSession] = await db
      .insert(shotSessions)
      .values({
        ...session,
        parameter_id: session.parameter_id || null,
        actual_score: session.actual_score || null,
        tasting_notes: session.tasting_notes || null,
        crema_quality: session.crema_quality || null,
        shot_rating: session.shot_rating || null,
      })
      .returning();
    return shotSession;
  }

  async getShotSessions(): Promise<ShotSession[]> {
    return await db
      .select()
      .from(shotSessions)
      .orderBy(shotSessions.created_at);
  }

  async getShotSessionsByParameterId(parameterId: number): Promise<ShotSession[]> {
    return await db
      .select()
      .from(shotSessions)
      .where(eq(shotSessions.parameter_id, parameterId))
      .orderBy(shotSessions.created_at);
  }

  async updateShotSession(id: number, updates: Partial<InsertShotSession>): Promise<ShotSession | undefined> {
    const [updatedSession] = await db
      .update(shotSessions)
      .set(updates)
      .where(eq(shotSessions.id, id))
      .returning();
    return updatedSession || undefined;
  }
}

export const storage = new DatabaseStorage();
